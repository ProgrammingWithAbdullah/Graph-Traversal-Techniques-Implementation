class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        if not self.is_empty():
            return self.items.pop()

    def peek(self):
        if not self.is_empty():
            return self.items[-1]

    def is_empty(self):
        return len(self.items) == 0

    def size(self):
        return len(self.items)

def swap_connections(graph, node1, node2):
    graph[node1], graph[node2] = graph[node2], graph[node1]
    if node1 in graph[node1] and node2 in graph[node2]:
        graph[node1][graph[node1].index(node1)] = node2
        graph[node2][graph[node2].index(node2)] = node1

def print_graph(graph):
    for vertex, neighbors in graph.items():
        print(f"Vertex {vertex}:", end=" ")
        print(neighbors)

def update_connections(graph, node1, node2):
    for vertex, neighbors in graph.items():
        for i, neighbor in enumerate(neighbors):
            if neighbor == node1:
                # Replace node1 with node2 if node2 is not already present
                    graph[vertex][i] = node2
            elif neighbor == node2:
                # Replace node2 with node1 if node1 is not already present
                    graph[vertex][i] = node1
    graph[node1] = [node2 if x == node1 else x for x in graph[node1]]
    graph[node2] = [node1 if x == node2 else x for x in graph[node2]]




def dfs(graph, start,initial, goal, vis):
    stack = Stack()
    visited = set()
    stack.push(start)
    while not stack.is_empty():
        current_vertex = stack.pop()
        if current_vertex not in visited:
            visited.add(current_vertex)
            vis[0] += 1
            if current_vertex == goal:
                swap_connections(graph, initial, goal)
                break
            for neighbor in graph[current_vertex]:
                if neighbor not in visited:
                    stack.push(neighbor)


graph = {
    0: [1, 3],
    1: [0,2,4],
    2: [1,5],
    3: [7, 4, 0],
    4: [1, 3, 5, 6],
    5: [2, 4, 8],
    6: [4, 7,8],
    7: [3,6],
    8: [5, 6]
}
vis = [0]

def swap_values_in_list(lst, value1, value2):
    for i in range(len(lst)):
        if lst[i] == value1:
            lst[i] = value2
        elif lst[i] == value2:
            lst[i] = value1

str1 ="012345768"
str2 = "012345678"
str1_list = list(str1)
str2_list = list(str2)
print("INITIAL STATE: ",str1)
print("GOAL STATE: ",str2)

for i in range(len(str1_list)):
    if str1_list[i] != str2_list[i]:
        a=int(str1_list[i])
        b=int(str2_list[i])
        dfs(graph, 1, b, a, vis)
        update_connections(graph,b, a)
        print_graph(graph)
        swap_values_in_list(str1_list, str1_list[i], str2_list[i])
        print(''.join(str1_list))

new_str1 = ''.join(str1_list)
new_str2 = ''.join(str2_list)


print("DFS ALGORITHM")
print("Number of nodes visited:", vis[0])
print("Path Cost is :", vis[0]-1)
